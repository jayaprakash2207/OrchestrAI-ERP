"""Generated FastAPI entrypoint for Acme Corp."""

from fastapi import FastAPI

from routes import router

app = FastAPI(title="Acme Corp")
app.include_router(router)


@app.get("/")
def root() -> dict[str, object]:
    return {"message": "Generated ERP starter app", "currencies": ['EUR', 'GBP', 'USD']}
