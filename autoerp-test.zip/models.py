"""SQLAlchemy models for Acme Corp."""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
