"""Pydantic schemas for Acme Corp."""

from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str = "healthy"
