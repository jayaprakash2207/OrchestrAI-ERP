#!/usr/bin/env bash
set -euo pipefail

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is not installed. Install it from https://docs.docker.com/get-docker/"
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose is not available. See https://docs.docker.com/compose/install/"
  exit 1
fi

if ! command -v python >/dev/null 2>&1; then
  echo "Python 3.11+ is required."
  exit 1
fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo ".env created from .env.example. Please review and update values before production use."
fi

docker compose build
docker compose up -d db

until docker compose exec -T db pg_isready -U "${DB_USER:-erp_user}" -d "${DB_NAME:-erp_db}" >/dev/null 2>&1; do
  echo "Waiting for database to be healthy..."
  sleep 2
done

docker compose up -d api
docker compose exec api alembic upgrade head || {
  echo "Migration failed. Review alembic logs and consider rollback before retrying."
  exit 1
}

docker compose up -d chroma
docker compose up -d frontend

echo "Setup completed successfully."
echo "API: http://localhost:8000"
echo "Docs: http://localhost:8000/docs"
echo "Frontend: http://localhost:3000"
echo "DB: localhost:5432"
echo "Next steps:"
echo "  1. Edit .env if needed"
echo "  2. Access frontend at http://localhost:3000"
echo "  3. Use 'docker compose logs -f' to view logs"
echo "  4. Use 'docker compose down' to stop services"
