"""Generated FastAPI entrypoint for RetailCo."""

from fastapi import FastAPI

from routes import router

app = FastAPI(title="RetailCo")
app.include_router(router)


@app.get("/")
def root() -> dict[str, object]:
    return {"message": "Generated ERP starter app", "currencies": ['EUR', 'USD']}
