"""SQLAlchemy models for RetailCo."""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
